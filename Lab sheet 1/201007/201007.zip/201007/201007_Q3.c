// 201007
// Question_3

#include <stdio.h>

int main(){
	char First = 'A';
	char second = 'C';
	char Third = 'T';
	int Age = 3;

	printf("how old is your %c%c%c?\n", second, First, Third);
	printf("%d years\n", Age);

	return 0;
}
