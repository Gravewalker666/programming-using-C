// 201007
// Question_2

#include <stdio.h>

int main(){
	printf("\"Hello\"\n");
	printf("what are you doing ?\n");
	printf("'my first day'\n");

	return 0;
}
