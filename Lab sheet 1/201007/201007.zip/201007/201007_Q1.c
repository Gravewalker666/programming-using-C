// 201007
// Question_1

#include <stdio.h>

int main(){
	printf("Name : Heshan Andrews\n");
	printf("Index Number: 201007\n");
	printf("Address: House of Elrond, Lothlorian, Middle-earth\n");
	printf("Date of Birth: 31.10.1999\n");

	return 0;
}