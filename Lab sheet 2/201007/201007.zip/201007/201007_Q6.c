//201007
//Question 06

#include <stdio.h>
#include <math.h>

int main(){
	double r = 5.4;

    printf("Area = %.2f \n", 3.14*pow(r, 2));// output: Area = 91.56

    return 0;
}
