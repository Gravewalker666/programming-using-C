//201007
//Question 07

#include <stdio.h>
#include <math.h>

int main(){
	double or = 7;
	double ir = 5;

	double area = 3.14*(pow(or, 2) - pow(ir, 2));

    printf("Surface area of the disk = %.2f \n", area);// output: Surface area of the disk = 75.36

    return 0;
}
